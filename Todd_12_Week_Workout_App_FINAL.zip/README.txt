Todd's 12-Week Workout Tracker — Final Version

Included:
- 12 selectable weeks
- Workout routines reconstructed from the supplied screenshots
- Back + Biceps completed with 3 clearly marked suggested exercises
- Weight and reps logging
- Automatic 90-second rest timer after each completed strength set
- RIR/failure notes where visible
- Stairs and 3-round ab circuits
- Previous-week weight display
- Progressive-overload prompt when all prior-week sets reach 10+ reps
- Local device storage
- Installable PWA files

Deploy all files in this folder to a static web host.
